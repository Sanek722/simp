﻿#include "dirent.h"
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#define size_direct 42
#define way "C:\\Users\\miste\\source\\repos\\konfig\\System"
using namespace std;
string PATH_user;        
int cd(string path) 
{
    path = way + path;
    DIR* directoria;
    dirent* dp;
    directoria = opendir(&path[0]);//открытие католога и возврат ссылки хранящей его информацию(файлы,папки)
    if (directoria)
    {
        PATH_user = path;
        return 1;
    }
    else //если директория не была найдена
    {
        return 0;
    }
}
int cat(string path)
{
    ifstream itf(way + path);
    if (!itf)
        return 0;
    string x;
    while (getline(itf, x))
    {
        cout << x << endl;
    }
    cout << endl;
    itf.close();
    return 1;
}
void ls()
{
    DIR* directoria;
    dirent* dp;
    directoria = opendir(&PATH_user[0]);//открытие католога и возврат ссылки хранящей его информацию(файлы,папки)
    while ((dp = readdir(directoria)) != NULL)//Функция readdir() возвращает название следующего файла в каталоге.
    {
        if (dp->d_name[0] != '.')
        {
            cout << dp->d_name << endl;
        }
    }
    closedir(directoria);
}
int pars(string* input) //парсинг строки и замена input на путь до
{                       //директории/файла в случае, если cmd равна 1 или 2
    int cmd = 0;
    string in = *input;
    string cdir;
    DIR* dir;
    switch (in[0])
    {
    case 99:                            // cat and cd
        if (in[1] == 100 and in[2] == 32) 
        {
            cmd = 1;
            *input = cdir.append(in, 3, in.size() - 3); // get ker
        }
        if (in[1] == 97 and in[2] == 116 and in[3] == 32) // cat
        {
            cmd = 2;
            (*input).erase(0, 4);
            return cmd;
        }
        break;
    case 108: // ls
        if (in[1] == 115)
        {
            cmd = 4;
        }
        break;
    case 112: // pwd
        if (in[1] == 119 and in[2] == 100)
        {
            cmd = 3;
        }
    default:

        break;
    }
    return cmd;
}
void callCMD(int cmd, string path)
{
    string help;
    switch (cmd)
    {
    case 1:
        if (!cd(path))
        {
            path.erase(path.rfind('\\'), 1);
            cout << "Директория " << path.erase(0, path.rfind('\\') + 1) << " не найдена\n";
        }
        break;
    case 2:
        if (!cat(path))
        {
            path.erase(path.rfind("\\"), path.size());
            cout << "Файл " << path << " не найден\n";
        };
        break;
    case 3://pwd
        if (path != "\\")
        {
            path.pop_back();
        }
        cout << path << endl;
        break;
    case 4:
        ls();
        break;
    default:
        break;
    }
}
int mainLoop()
{
    int error = 0, cmd = 0, e = 0;
    PATH_user = way;
    PATH_user += "\\";
    string dir = PATH_user;
    string input;
    cout << "> ";
    int i = 0;
    while (!error)
    {
        dir.erase(0, size_direct - 1);
        getline(cin, input);
        if (input == "exit")
        {
            error = 1;
        }
        else
        {
            cmd = pars(&input); //парсинг строки и изменение input на аргументы если команда их имеет
            if (cmd == 1)       //если команда cd
            {
                if (input == "..") //если аргумент перехода назад
                {
                    if (dir == "\\")
                    {
                        cout << "Вы в корне файловой системы\n";
                        e = 1;
                    }
                    else
                    {
                        dir.pop_back();
                        dir.erase(dir.rfind("\\") + 1, dir.size()); //для удаления последней директории из пути
                    }
                }
                else
                {
                    e = 1;
                    input += '\\';
                    dir += input;
                    callCMD(cmd, dir);
                }
            }
            if (!e)
            {
                if (cmd == 2)// cat
                {
                    input = dir + input;
                    callCMD(cmd, input);
                }
                else
                {
                    callCMD(cmd, dir);//pwd
                }
            }
            cout << "> ";
            cmd = 0; //обнуление переменных
            e = 0;   //обнуление переменных
            if (PATH_user == way)
            {
                dir = PATH_user + "\\";
            }
            else
            {
                dir = PATH_user;
            }
        }
    }
    return error;
}
int main()
{
    setlocale(LC_ALL, "rus");
    return mainLoop();
}